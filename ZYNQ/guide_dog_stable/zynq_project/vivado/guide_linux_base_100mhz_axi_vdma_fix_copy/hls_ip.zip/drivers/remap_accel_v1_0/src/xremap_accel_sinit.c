// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xremap_accel.h"

extern XRemap_accel_Config XRemap_accel_ConfigTable[];

#ifdef SDT
XRemap_accel_Config *XRemap_accel_LookupConfig(UINTPTR BaseAddress) {
	XRemap_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XRemap_accel_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XRemap_accel_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XRemap_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XRemap_accel_Initialize(XRemap_accel *InstancePtr, UINTPTR BaseAddress) {
	XRemap_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XRemap_accel_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XRemap_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XRemap_accel_Config *XRemap_accel_LookupConfig(u16 DeviceId) {
	XRemap_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XREMAP_ACCEL_NUM_INSTANCES; Index++) {
		if (XRemap_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XRemap_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XRemap_accel_Initialize(XRemap_accel *InstancePtr, u16 DeviceId) {
	XRemap_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XRemap_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XRemap_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

