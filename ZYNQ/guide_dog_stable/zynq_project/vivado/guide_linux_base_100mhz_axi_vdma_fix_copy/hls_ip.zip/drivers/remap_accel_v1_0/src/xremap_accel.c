// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xremap_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XRemap_accel_CfgInitialize(XRemap_accel *InstancePtr, XRemap_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XRemap_accel_Start(XRemap_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XRemap_accel_IsDone(XRemap_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XRemap_accel_IsIdle(XRemap_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XRemap_accel_IsReady(XRemap_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XRemap_accel_EnableAutoRestart(XRemap_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XRemap_accel_DisableAutoRestart(XRemap_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XRemap_accel_Set_img_in(XRemap_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_IN_DATA, (u32)(Data));
    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XRemap_accel_Get_img_in(XRemap_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_IN_DATA);
    Data += (u64)XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_IN_DATA + 4) << 32;
    return Data;
}

void XRemap_accel_Set_map_x(XRemap_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_X_DATA, (u32)(Data));
    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_X_DATA + 4, (u32)(Data >> 32));
}

u64 XRemap_accel_Get_map_x(XRemap_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_X_DATA);
    Data += (u64)XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_X_DATA + 4) << 32;
    return Data;
}

void XRemap_accel_Set_map_y(XRemap_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_Y_DATA, (u32)(Data));
    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XRemap_accel_Get_map_y(XRemap_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_Y_DATA);
    Data += (u64)XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_MAP_Y_DATA + 4) << 32;
    return Data;
}

void XRemap_accel_Set_img_out(XRemap_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_OUT_DATA, (u32)(Data));
    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XRemap_accel_Get_img_out(XRemap_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_OUT_DATA);
    Data += (u64)XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IMG_OUT_DATA + 4) << 32;
    return Data;
}

void XRemap_accel_Set_rows(XRemap_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_ROWS_DATA, Data);
}

u32 XRemap_accel_Get_rows(XRemap_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_ROWS_DATA);
    return Data;
}

void XRemap_accel_Set_cols(XRemap_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_COLS_DATA, Data);
}

u32 XRemap_accel_Get_cols(XRemap_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_COLS_DATA);
    return Data;
}

void XRemap_accel_InterruptGlobalEnable(XRemap_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_GIE, 1);
}

void XRemap_accel_InterruptGlobalDisable(XRemap_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_GIE, 0);
}

void XRemap_accel_InterruptEnable(XRemap_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IER);
    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IER, Register | Mask);
}

void XRemap_accel_InterruptDisable(XRemap_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IER);
    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XRemap_accel_InterruptClear(XRemap_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_ISR, Mask);
}

u32 XRemap_accel_InterruptGetEnabled(XRemap_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_IER);
}

u32 XRemap_accel_InterruptGetStatus(XRemap_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRemap_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_ACCEL_CONTROL_ADDR_ISR);
}

