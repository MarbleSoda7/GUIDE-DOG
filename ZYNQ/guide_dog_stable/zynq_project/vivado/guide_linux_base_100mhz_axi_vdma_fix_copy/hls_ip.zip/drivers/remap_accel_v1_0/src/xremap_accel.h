// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XREMAP_ACCEL_H
#define XREMAP_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xremap_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XRemap_accel_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XRemap_accel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XRemap_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XRemap_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XRemap_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XRemap_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XRemap_accel_Initialize(XRemap_accel *InstancePtr, UINTPTR BaseAddress);
XRemap_accel_Config* XRemap_accel_LookupConfig(UINTPTR BaseAddress);
#else
int XRemap_accel_Initialize(XRemap_accel *InstancePtr, u16 DeviceId);
XRemap_accel_Config* XRemap_accel_LookupConfig(u16 DeviceId);
#endif
int XRemap_accel_CfgInitialize(XRemap_accel *InstancePtr, XRemap_accel_Config *ConfigPtr);
#else
int XRemap_accel_Initialize(XRemap_accel *InstancePtr, const char* InstanceName);
int XRemap_accel_Release(XRemap_accel *InstancePtr);
#endif

void XRemap_accel_Start(XRemap_accel *InstancePtr);
u32 XRemap_accel_IsDone(XRemap_accel *InstancePtr);
u32 XRemap_accel_IsIdle(XRemap_accel *InstancePtr);
u32 XRemap_accel_IsReady(XRemap_accel *InstancePtr);
void XRemap_accel_EnableAutoRestart(XRemap_accel *InstancePtr);
void XRemap_accel_DisableAutoRestart(XRemap_accel *InstancePtr);

void XRemap_accel_Set_img_in(XRemap_accel *InstancePtr, u64 Data);
u64 XRemap_accel_Get_img_in(XRemap_accel *InstancePtr);
void XRemap_accel_Set_map_x(XRemap_accel *InstancePtr, u64 Data);
u64 XRemap_accel_Get_map_x(XRemap_accel *InstancePtr);
void XRemap_accel_Set_map_y(XRemap_accel *InstancePtr, u64 Data);
u64 XRemap_accel_Get_map_y(XRemap_accel *InstancePtr);
void XRemap_accel_Set_img_out(XRemap_accel *InstancePtr, u64 Data);
u64 XRemap_accel_Get_img_out(XRemap_accel *InstancePtr);
void XRemap_accel_Set_rows(XRemap_accel *InstancePtr, u32 Data);
u32 XRemap_accel_Get_rows(XRemap_accel *InstancePtr);
void XRemap_accel_Set_cols(XRemap_accel *InstancePtr, u32 Data);
u32 XRemap_accel_Get_cols(XRemap_accel *InstancePtr);

void XRemap_accel_InterruptGlobalEnable(XRemap_accel *InstancePtr);
void XRemap_accel_InterruptGlobalDisable(XRemap_accel *InstancePtr);
void XRemap_accel_InterruptEnable(XRemap_accel *InstancePtr, u32 Mask);
void XRemap_accel_InterruptDisable(XRemap_accel *InstancePtr, u32 Mask);
void XRemap_accel_InterruptClear(XRemap_accel *InstancePtr, u32 Mask);
u32 XRemap_accel_InterruptGetEnabled(XRemap_accel *InstancePtr);
u32 XRemap_accel_InterruptGetStatus(XRemap_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
