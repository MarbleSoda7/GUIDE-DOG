// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of img_in
//        bit 31~0 - img_in[31:0] (Read/Write)
// 0x14 : Data signal of img_in
//        bit 31~0 - img_in[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of grid_lut
//        bit 31~0 - grid_lut[31:0] (Read/Write)
// 0x20 : Data signal of grid_lut
//        bit 31~0 - grid_lut[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of img_out
//        bit 31~0 - img_out[31:0] (Read/Write)
// 0x2c : Data signal of img_out
//        bit 31~0 - img_out[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of rows
//        bit 31~0 - rows[31:0] (Read/Write)
// 0x38 : reserved
// 0x3c : Data signal of cols
//        bit 31~0 - cols[31:0] (Read/Write)
// 0x40 : reserved
// 0x44 : Data signal of grid_cols
//        bit 31~0 - grid_cols[31:0] (Read/Write)
// 0x48 : reserved
// 0x4c : Data signal of grid_rows
//        bit 31~0 - grid_rows[31:0] (Read/Write)
// 0x50 : reserved
// 0x54 : Data signal of grid_step
//        bit 31~0 - grid_step[31:0] (Read/Write)
// 0x58 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL        0x00
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_GIE            0x04
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_IER            0x08
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_ISR            0x0c
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_IN_DATA    0x10
#define XREMAP_GRID_ACCEL_CONTROL_BITS_IMG_IN_DATA    64
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_LUT_DATA  0x1c
#define XREMAP_GRID_ACCEL_CONTROL_BITS_GRID_LUT_DATA  64
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_OUT_DATA   0x28
#define XREMAP_GRID_ACCEL_CONTROL_BITS_IMG_OUT_DATA   64
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_ROWS_DATA      0x34
#define XREMAP_GRID_ACCEL_CONTROL_BITS_ROWS_DATA      32
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_COLS_DATA      0x3c
#define XREMAP_GRID_ACCEL_CONTROL_BITS_COLS_DATA      32
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_COLS_DATA 0x44
#define XREMAP_GRID_ACCEL_CONTROL_BITS_GRID_COLS_DATA 32
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_ROWS_DATA 0x4c
#define XREMAP_GRID_ACCEL_CONTROL_BITS_GRID_ROWS_DATA 32
#define XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_STEP_DATA 0x54
#define XREMAP_GRID_ACCEL_CONTROL_BITS_GRID_STEP_DATA 32

