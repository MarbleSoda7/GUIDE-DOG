// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xremap_grid_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XRemap_grid_accel_CfgInitialize(XRemap_grid_accel *InstancePtr, XRemap_grid_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XRemap_grid_accel_Start(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XRemap_grid_accel_IsDone(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XRemap_grid_accel_IsIdle(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XRemap_grid_accel_IsReady(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XRemap_grid_accel_EnableAutoRestart(XRemap_grid_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XRemap_grid_accel_DisableAutoRestart(XRemap_grid_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_AP_CTRL, 0);
}

void XRemap_grid_accel_Set_img_in(XRemap_grid_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_IN_DATA, (u32)(Data));
    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XRemap_grid_accel_Get_img_in(XRemap_grid_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_IN_DATA);
    Data += (u64)XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_IN_DATA + 4) << 32;
    return Data;
}

void XRemap_grid_accel_Set_grid_lut(XRemap_grid_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_LUT_DATA, (u32)(Data));
    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_LUT_DATA + 4, (u32)(Data >> 32));
}

u64 XRemap_grid_accel_Get_grid_lut(XRemap_grid_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_LUT_DATA);
    Data += (u64)XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_LUT_DATA + 4) << 32;
    return Data;
}

void XRemap_grid_accel_Set_img_out(XRemap_grid_accel *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_OUT_DATA, (u32)(Data));
    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XRemap_grid_accel_Get_img_out(XRemap_grid_accel *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_OUT_DATA);
    Data += (u64)XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IMG_OUT_DATA + 4) << 32;
    return Data;
}

void XRemap_grid_accel_Set_rows(XRemap_grid_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_ROWS_DATA, Data);
}

u32 XRemap_grid_accel_Get_rows(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_ROWS_DATA);
    return Data;
}

void XRemap_grid_accel_Set_cols(XRemap_grid_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_COLS_DATA, Data);
}

u32 XRemap_grid_accel_Get_cols(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_COLS_DATA);
    return Data;
}

void XRemap_grid_accel_Set_grid_cols(XRemap_grid_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_COLS_DATA, Data);
}

u32 XRemap_grid_accel_Get_grid_cols(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_COLS_DATA);
    return Data;
}

void XRemap_grid_accel_Set_grid_rows(XRemap_grid_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_ROWS_DATA, Data);
}

u32 XRemap_grid_accel_Get_grid_rows(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_ROWS_DATA);
    return Data;
}

void XRemap_grid_accel_Set_grid_step(XRemap_grid_accel *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_STEP_DATA, Data);
}

u32 XRemap_grid_accel_Get_grid_step(XRemap_grid_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GRID_STEP_DATA);
    return Data;
}

void XRemap_grid_accel_InterruptGlobalEnable(XRemap_grid_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GIE, 1);
}

void XRemap_grid_accel_InterruptGlobalDisable(XRemap_grid_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_GIE, 0);
}

void XRemap_grid_accel_InterruptEnable(XRemap_grid_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IER);
    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IER, Register | Mask);
}

void XRemap_grid_accel_InterruptDisable(XRemap_grid_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IER);
    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XRemap_grid_accel_InterruptClear(XRemap_grid_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XRemap_grid_accel_WriteReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_ISR, Mask);
}

u32 XRemap_grid_accel_InterruptGetEnabled(XRemap_grid_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_IER);
}

u32 XRemap_grid_accel_InterruptGetStatus(XRemap_grid_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XRemap_grid_accel_ReadReg(InstancePtr->Control_BaseAddress, XREMAP_GRID_ACCEL_CONTROL_ADDR_ISR);
}

